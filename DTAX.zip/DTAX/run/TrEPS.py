import os

os.system("C:\\DTAX\\python\\demand_shift.py")
os.system("C:\\DTAX\\run\\dsxgui.exe")
