import shutil
import os
from datetime import datetime

path1='D:\\FTP_KC\\'
path2='D:\\FTP_KC\\output\\'

folder_name = 'D:\\FTP_KC\\output'
if not os.path.exists(folder_name):
    os.mkdir(folder_name)

filename3='C:\DTAX\\run\\predict\\VehTrajectory.dat'
filename4='D:\\FTP_KC\\output\\VehTrajectory.dat'
shutil.copy2(filename3,filename4)

   

#The following piece of code performs the data smooting using the simple moving average over 5 minutes
data_dict = dict()
for file_type in ['LinkVolume','OutFlow','OutLinkDent','OutLinkSpeedAll']:
    datafile = open(path1+file_type+'.dat','r')
    outputfile = open(path2+file_type+'.dat','w')
    lines=datafile.readlines()
    datafile.close()
    blocksize=201
    i=8
    outputfile.write(''.join(lines[:i+blocksize]))
    i=i+(blocksize+3)
    count=1 #we are skipping the first block. so we are not replacing it with the simple moving average value
    #for the first 4 minutes because there is not enough data to calculate the average of the past 5 minute, we are simply replacing them with the value calculated for the 5th minute
    while (count<=4 and i+blocksize < len(lines)):
        data_dict[count] = [map(float,line.split( )) for line in lines[i:i+blocksize]]
        for index1 in range(len(data_dict[count])):
            for index2 in range(len(data_dict[count][index1])):
                data_dict[count][index1][index2] = data_dict[count][index1][index2]/5
        for j in range(4):
            temp = [map(float,line.split( )) for line in lines[i+(j+1)*(blocksize+3):i+blocksize+(j+1)*(blocksize+3)]]
            for index1 in range(len(data_dict[count])):
                for index2 in range(len(data_dict[count][index1])):
                    data_dict[count][index1][index2] = data_dict[count][index1][index2] + temp[index1][index2]/5
        outputfile.write('\n')
        outputfile.write('\n')
        outputfile.write(lines[i-1])
        i=i+(blocksize+3)
        for index1 in range(len(data_dict[count])):
            for index2 in range(len(data_dict[count][index1])):
                temp = "%.2f" % data_dict[count][index1][index2]
                if file_type == 'LinkVolume':                    
                    outputfile.write(' '*(10-len(temp))+temp)
                else:
                    outputfile.write(' '*(8-len(temp))+temp)
            outputfile.write('\n')
        count=count+1
    while (count<=120 and count>=5 and i+blocksize <= len(lines)):
        data_dict[count] = [map(float,line.split( )) for line in lines[i:i+blocksize]]
        for index1 in range(len(data_dict[count])):
            for index2 in range(len(data_dict[count][index1])):
                data_dict[count][index1][index2] = data_dict[count][index1][index2]/5
        for j in range(4):
            temp = [map(float,line.split( )) for line in lines[i-(j+1)*(blocksize+3):i+blocksize-(j+1)*(blocksize+3)]]
            for index1 in range(len(data_dict[count])):
                for index2 in range(len(data_dict[count][index1])):
                    data_dict[count][index1][index2] = data_dict[count][index1][index2] + temp[index1][index2]/5
        outputfile.write('\n')
        outputfile.write('\n')
        outputfile.write(lines[i-1])
        for index1 in range(len(data_dict[count])):
            for index2 in range(len(data_dict[count][index1])):
                temp = "%.2f" % data_dict[count][index1][index2]
                if file_type == 'LinkVolume':                    
                    outputfile.write(' '*(10-len(temp))+temp)
                else:
                    outputfile.write(' '*(8-len(temp))+temp)
            outputfile.write('\n')
        i=i+blocksize+3
        count=count+1
    outputfile.close()

for file_type in ['LinkVolume','OutFlow','OutLinkDent','OutLinkSpeedAll']:
    filename=path1+file_type+'.dat'
    os.remove(filename) 
