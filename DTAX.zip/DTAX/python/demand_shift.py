import random
from datetime import datetime
import numpy
import shutil
import urllib
import os

interval=5
interval2=5.0

folder_name = 'D:\\FTP_KC'
if not os.path.exists(folder_name):
    os.mkdir(folder_name)

timenow=datetime.now()
targettime=str(timenow.hour*60+numpy.ceil(timenow.minute/interval2)*interval)
with open('C:\\DTAX\\python\\timeZero.dat', 'w') as wfile:
    wfile.write(str(timenow))
wfile.close()

flagdata=open('C:\\DTAX\\python\\hist.txt','w')
flagdata.write('0'+'\n')
flagdata.write('0')

filename='C:\DTAX\\python\\demand.dat'

filename2='C:\DTAX\\run\estimate\demand.dat'
filename3='C:\DTAX\\run\predict\demand.dat'
filename4='C:\DTAX\\run\odestimate\demand_hist.dat'
filename5='C:\DTAX\\run\odpredict\demand_hist.dat'

def loadworkzone():
	cwd='C:\\DTAX\\run'
	workzone = urllib.urlopen("https://imrcp.data-env.com/workzone.dat")
	workzoneout1=open(cwd+'\\estimate\\workzone.dat','w')
	workzoneout2=open(cwd+'\predict\\workzone.dat','w')
	lines=workzone.readlines()
	for i in range(1,len(lines)):
		workzoneout2.write(lines[i])
		workzoneout1.write(lines[i])  
	workzoneout1.close()
	workzoneout2.close()
	print ('workzone loaded')
	return

def loadweather():
	cwd='C:\\DTAX\\run'
	weather = urllib.urlopen("https://imrcp.data-env.com/weather.dat")
	weatherout1=open(cwd+'\\estimate\\weather.dat','w')
	weatherout2=open(cwd+'\predict\\weather.dat','w')
	lines=weather.readlines()
	for i in range(1,len(lines)):
		weatherout2.write(lines[i])
		weatherout1.write(lines[i])  
	weatherout1.close()
	weatherout2.close()
	print ('weather loaded')
	return




if __name__ == "__main__":
    
    ttfile=open(filename,'r')
    ttfile2=open(filename2,'w')
    lines=ttfile.readlines()
    ttfile2.write(lines[0])
    ttfile2.write(lines[1])
    i=2
    count=0
    while (i<len(lines)):
        if targettime in lines[i]:
            flag=i
            for m in range (flag, len(lines)):
                ttfile2.write(lines[m])
            for m in range (2, flag):
                ttfile2.write(lines[m])
            break
        else:
            i=i+1
    ttfile.close()
    ttfile2.close()
shutil.copy2(filename2,filename3)
shutil.copy2(filename2,filename4)
shutil.copy2(filename2,filename5)
loadworkzone()
loadweather()



