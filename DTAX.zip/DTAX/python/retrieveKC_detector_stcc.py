import urllib
import numpy as np
import shutil
from datetime import datetime

class Detector:

   def __init__(self, his_volume,his_speed, his_occ):
      self.his_volume = his_volume
      self.his_speed = his_speed
      self.his_occ = his_occ
      self.count=0
      self.volume=0
      self.occ=0
      self.speed=0

   def retrive(self,volume,speed,occ):
      self.volume=volume+self.volume
      self.occ=occ+self.occ
      self.speed=speed+self.speed
      self.count=self.count+1


   def generate_1min(self,outfile):
       occ_para=2
       if self.count==0:
           outfile.write(str(self.his_volume)+'\t'+str(self.his_speed)+'\t'+str(self.his_occ*occ_para) +'\n')
       else:
           outfile.write(str(self.volume/self.count)+'\t'+str(self.speed/self.count)+'\t'+str(self.occ/self.count*occ_para) +'\n')

   def generate_5min(self,outfile):
       occ_para=2
       if self.count==0:
           outfile.write(str(self.his_volume*5)+'\t'+str(self.his_speed)+'\t'+str(self.his_occ*occ_para) +'\n')
       else:
           outfile.write(str(self.volume*5/self.count)+'\t'+str(self.speed/self.count)+'\t'+str(self.occ/self.count*occ_para) +'\n')

   def generate_15min(self,outfile):
       occ_para=2
       if self.count==0:
           outfile.write(str(self.his_volume*15)+'\t'+str(self.his_speed)+'\t'+str(self.his_occ*occ_para) +'\n')
       else:
           outfile.write(str(self.volume*15/self.count)+'\t'+str(self.speed/self.count)+'\t'+str(self.occ/self.count*occ_para) +'\n')


def get_hist(detectordata,histdata):
   flagdata=open('C:\\DTAX\\python\\hist.txt','w')
   hour=datetime.now().hour
   minute=datetime.now().minute
   time=(hour*60+minute)/5+1
   count=(hour*60+minute)%5
   flagdata=open('C:\\DTAX\\python\\hist.txt','w')
   flagdata.write(str(time)+'\n')
   flagdata.write(str(count))
   flagdata.close()
   hist_now=histdata[time].split(',')
   j=1
   while j<len(hist_now):
      detector_i=Detector(float(hist_now[j])/5,float(hist_now[j+1]),float(hist_now[j+2]))
      j=j+3
      detectordata.append(detector_i)
   return detectordata
   

		   
if __name__ == "__main__":
	detectormapping=open('C:\\DTAX\\python\\detector_mapping_to_link.txt','r')
	detectorid=[]
	lines=detectormapping.readlines()
	histdata=open('C:\\DTAX\\python\\detector_hist.csv','r')
	histlines=histdata.readlines()
	for i in range(len(lines)):
		detectorid.append(lines[i][0:4])
	detectormapping.close()

	detectordata=[]
	get_hist(detectordata,histlines)


	detector = urllib.urlopen("https://imrcp.data-env.com/detector.dat")
	detectorout1=open('C:\\DTAX\\run\\stcc\\detector.dat','w')  # one minute interval
	lines=detector.readlines()
	for i in range(1,len(lines)):
		linearray=lines[i].split()
		if linearray[0] in detectorid and '-100' not in linearray and (float(linearray[2])+float(linearray[3])+float(linearray[4]))>0:
			linkid=detectorid.index(linearray[0])
			detectordata[linkid].retrive(float(linearray[2]),float(linearray[3]) ,float(linearray[4]))  #flow
	for i in range(len(detectorid)):
		detectordata[i].generate_1min(detectorout1)
	detectorout1.close()
	print ('detector data loaded')         
